import pymysql
import pandas as pd
def get_connection():
    conn = pymysql.connect(host="localhost",user="root",database="protal_kern_BGC")
    cur = conn.cursor()
    return conn, cur

df = pd.read_excel(r"D:\Users\mkachhadiya\Downloads\CA_kern_analysis_MUF.xlsx",sheet_name="Sheet1")
table_name = "case_no_table"
sql_tuple = []
def insert_into_db(df,table_name):
    for _, row in df.iterrows():
        case_type = row["Case Type"]
        case_no = row["case_no"]
        sql_tuple.append((case_type,case_no))

    conn, cur = get_connection()
    query = f"INSERT IGNORE INTO {table_name} (case_type,case_no) VALUES (%s, %s)"
    cur.executemany(query,sql_tuple)
    conn.commit()
    cur.close()
    conn.close()
    print("data inserted successfully.....")

def create_table(table_name):
    query = f"""CREATE TABLE IF NOT EXISTS {table_name} (id int auto_increment primary key,
    case_type VARCHAR(150),
    case_no VARCHAR(200) UNIQUE,
    status VARCHAR(100) DEFAULT "pending"
    )"""
    conn, cur = get_connection()
    cur.execute(query,)
    conn.commit()
    cur.close()
    conn.close()

# if __name__ == "__main__":
    # create_table(table_name)
    # insert_into_db(df,table_name)

'''
cd D:\your-folder-path
git init
git add .
git commit -m "first commit"
git remote add origin https://github.com/username/repo.git
git branch -M main
git push -u origin main
'''