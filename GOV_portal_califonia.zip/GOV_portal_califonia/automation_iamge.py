#make sure to install paddlepaddle
# and i have attached requiremnts.txt -- all packages for running this script
# kindly make sure to run bellow command in python environment
# python -m pip install paddlepaddle -i https://www.paddlepaddle.org.cn/packages/stable/cpu/
# --> this is installation for OCR ,and site link given so it download it from that site insted of python packages

import json
import random
import time
from paddleocr import PaddleOCR
from DrissionPage import ChromiumPage, ChromiumOptions
import tempfile
from curl_cffi import requests

def random_wait(a=1, b=2):
    t = random.uniform(a, b)
    time.sleep(t)


# Create temp profile (acts like incognito)
temp_dir = tempfile.mkdtemp()

co = ChromiumOptions()
co.set_user_data_path(temp_dir)  # fresh profile = no cookies
co.headless(False)
# wait for page load
time.sleep(5)
page = ChromiumPage(co)
page.get("https://2captcha.com/demo/normal/")
time.sleep(8)
image_src = page.ele('xpath://form//img[contains(@alt,"normal")]').attr('src')
if image_src:
    image_path = "captch_image.jpg"
    image_url = image_src
    print("image url :",image_url)
    response = requests.get(image_url,impersonate="chrome101",timeout=20)
    if response.status_code == 200:
        print("content-type:", response.headers.get("content-type"))
        print("content length:", len(response.content))
        print("first 50 bytes:", response.content[:50])
        with open(image_path,"wb") as f:
            f.write(response.content)
            print('image save successfully..')
        # make sure to install paddlepaddle
        ocr = PaddleOCR(use_doc_orientation_classify=False,
                        use_doc_unwarping=False,
                        use_textline_orientation=True)
        image_path = r"captch_image.jpg"
        result = ocr.predict(input=image_path)
        detected_text = "".join(result[0]["rec_texts"])
        print(detected_text)

        #PLACE THIS IN INPUT FILED AND THEN CLICK ON SUBMIT BUTTON
        input_ele = page.ele('xpath://input[@id="simple-captcha-field"]')
        if input_ele:
            input_ele.click()
            input_ele.input(detected_text)
            random_wait(a=1, b=2)
        else:
            print("input found issue...")

        #now button click
        button_ele = page.ele("xpath://button[@type='submit' and contains(text(), 'Check')]")
        if button_ele:
            button_ele.click()
        else:
            print("some issue found...")
        random_wait(a=3, b=4)
        success_message_show =  page.ele('xpath://p[contains(text(),"Captcha is passed successfully!")]')
        if success_message_show:
            page.run_js(f'console.log({json.dumps("OCR OUTPUT:" + detected_text)})')
            print("captch solve..")
        else:
            print("having issue in captch.....")


        #
        # input_xpath = '//input[@id="simple-captcha-field"]'
        #
        # #check if element exits
        # if page.exist(input_xpath):
        #     page.click(input())
        #     page.set_value(input_xpath,detected_text)
        #     random_wait(a=1, b=2)
        #     button_xpath = "//button[@type='submit' and contains(text(), 'Check')]"
        #     if page.exist(button_xpath):
        #         page.click(button_xpath)
        #     success_messsage = '//p[contains(text(),"Captcha is passed successfully!")]'
        #     if page.exist(success_messsage):
        #         page.run_js(f'console.log({json.dumps("OCR OUTPUT:" + detected_text)})')
        #         print("catcha solve..")
# =====================================================================================================
#             # i call js scrpit here
#         js_file =r"K:\Mansi\learning\image_automation\ocr.js"
#         time.sleep(10)
#         res = subprocess.run([r"C:\Program Files\nodejs\node.exe", str(js_file), image_path],capture_output=True,text=True)
#         output = res.stdout.strip()
#         error_ = res.stderr.strip()
#         if output:
#             page.run_js(f'console.log({json.dumps("OCR OUTPUT:" + output)})')
#         if error_:
#             page.run_js(f'console.error({json.dumps("OCR ERROR: " + error_)})')
#     else:
#         print("download fail..")
# else:
#     print("image_src not found..")
# time.sleep(20)
# =====================================================================================

# page.ele('text:Login').click()
# time.sleep(5)
# page.ele('#edit-name').input('kristi.reed@genuinedataservices.com')
# page.ele('#edit-pass').input('D@t@GDS2025!!')
# # input("Press Enter to close...")
## time.sleep(10)
# page.ele('#edit-submit').click()
# time.sleep(2)
# page.ele('xpath://a[contains(text(),"Case Search")]').click()
#
# time.sleep(2)
# case_input = page.ele('xpath://div//label[contains(text(),"Case Number")]/following-sibling::div/input')
# case_input.scroll.to_see()
# case_no = "26CSB00326"
# case_input.input(case_no)  # <-- your case number
# time.sleep(15)
# page.ele('#edit-submit').click()
# time.sleep(5)
# html = page.html
# save_page(case_no)
# print(f"{case_no}.html saved successfully")
# #========================try if data present else skip==============================
# rows = page.ele('xpath://div[@class="search-result-page-tag"]//table//tbody//tr')
# for data in rows:
#     link = data.ele("tag:a")
#     case_no = link.text.strip()
#     print("case no :", case_no)
#     link.click()
#     page.wait.load_complete()
#     random_wait(a=5, b=6)
#     save_page(case_no)
#     random_wait(a=2, b=4)


# ===========================================================================
# lst = ["26FLB00761","26FLR00060","26FLS00046","26CSB00326"]
# lst = [f"25FLB{str(i).zfill(5)}" for i in range(61, 853)]
# for i in lst:
#     case_input = page.ele('xpath://div//label[contains(text(),"Case Number")]/following-sibling::div/input')
#     case_input.scroll.to_see()
#     case_input.clear()
#     case_input.clear()
#     case_input.input(i)  # <-- your case number
#     random_wait(a=5, b=6)
#     page.ele('#edit-submit').click()
#     random_wait(a=5, b=8)
#     html = page.html
#     save_page(i)
#     random_wait(a=1, b=3)

# from playwright.sync_api import sync_playwright
# import time
# import random
#
# def human_delay(a=1.0, b=3.0):
#     time.sleep(random.uniform(a, b))
#
# with sync_playwright() as p:
#     browser = p.chromium.launch(
#         headless=False,  # IMPORTANT: keep visible
#         args=[
#             "--start-maximized",
#             "--disable-blink-features=AutomationControlled"
#         ]
#     )
#
#     context = browser.new_context(
#         viewport=None,
#         user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
#                    "AppleWebKit/537.36 (KHTML, like Gecko) "
#                    "Chrome/120.0.0.0 Safari/537.36"
#     )
#
#     page = context.new_page()
#
#     # Go to site
#     page.goto("https://portal.kern.courts.ca.gov/", timeout=60000)
#
#     # wait like a human
#     human_delay(15, 25)
#
#     # Example interaction
#     # page.click("text=Search")  # adjust selector
#
#     # Keep browser open
#     input("Press ENTER to close...")
#     browser.close()


# import time
#
# from DrissionPage import ChromiumPage, ChromiumOptions
#
# co = ChromiumOptions()
# co.headless(False)
# co.set_user_agent(
#     'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
#     '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
# )
# page = ChromiumPage(co)
# page.get('https://portal.kern.courts.ca.gov/')
#
# time.sleep(15)


# from selenium import webdriver
# import undetected_chromedriver as uc
#
# from selenium.webdriver.common.by import By
# import time
#
# driver = webdriver.Chrome()
# options = uc.ChromeOptions()
# options.add_argument("--start-maximized")
# options.add_argument("--ignore-certificate-errors")
# options.add_argument("--ignore-ssl-errors")
# options.add_argument("--allow-insecure-localhost")
# options.add_argument("--disable-web-security")
# driver.get("https://portal.kern.courts.ca.gov/")
#
# time.sleep(10)
#
# # Example: click "Smart Search" (inspect karke selector lena padega)
# # driver.find_element(By.XPATH, "//span[text()='Smart Search']").click()