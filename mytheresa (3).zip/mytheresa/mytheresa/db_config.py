import pymysql
from datetime import datetime
from slack_sdk import WebClient

#plp_data
#this page save data of home page to get 4  listed category (women,man,kids,life)
token = "xoxb-10870893147332-10865349024294-GoMcPucxj1l6XffVzSrdEkTO"
current_year_month = datetime.now().strftime("%Y%m")
main_page_path = fr"G:\pagesave\MYTHERESA\category_name_pages\main_page.html"
plp_data_logs_file = fr"G:\Mansi\projects\scrapy_project\mytheresa\logs\plp_data_logs.txt"

category_table = "category_listing_table"
plp_page_save_detail_table = "plp_page_save_detail_table"
plp_page_read_table = "plp_page_read_table"
unique_pdp_url = "unique_pdp_url"
pdp_data_table = "pdp_data_table"

conn = pymysql.connect(host="localhost",user='root')
cur = conn.cursor()
cur.execute("create database if not exists mytheresa_202604")
conn.commit()
conn.close()
def connection_():
    conn = pymysql.connect(host="localhost",user='root',database='mytheresa_202604',cursorclass=pymysql.cursors.DictCursor)
    cur = conn.cursor()
    return conn, cur
def send_message(message):
    client = WebClient(token=token)
    chanel_id = "C0ARLS9HUKW"
    client.chat_postMessage(channel=chanel_id,text=message)

def create_table():
    conn, cur = connection_()
    #table for storing category_data
    query = f"""create table if not exists {category_table} (
    id int auto_increment primary key,
    main_cat_name varchar(100),
    category_name varchar(200),
    category_url text,
    sub_cat_name varchar(200),
    sub_cat_url text, 
    hash_key varchar(200),
    parent_cat_id int(40),
    level_id int(40),
    status varchar(150) default 'pending',
    index cat_index (category_name,hash_key),
    constraint unique_value unique (hash_key)
    )engine=InnoDB charset=utf8mb4 collate=utf8mb4_unicode_ci"""
    cur.execute(query)
    conn.commit()

    #table for storing plp pagination pagesave info only not plp data
    query1 = f"""create table if not exists {plp_page_save_detail_table} (
    id int auto_increment primary key,
    main_cat_name varchar(100),
    category_name varchar(200),
    category_url text,
    sub_cat_2_name varchar(200),
    sub_cat_2_url varchar(200),
    page_no int(25),
    page_save_path varchar(255),
    hash_key varchar(200),
    status varchar(20) default "pending",
    index set_index_page_path (page_save_path,category_name,main_cat_name),
    constraint unique_value unique (hash_key)
    )engine=InnoDB charset=utf8mb4 collate=utf8mb4_unicode_ci"""
    cur.execute(query1)
    conn.commit()

    #table for storing plp data
    query2 = f"""Create table if not exists {plp_page_read_table}(
    id int auto_increment primary key,
    product_name VARCHAR(250),
    product_url TEXT,
    product_price INT,
    currency VARCHAR(10),
    designer_name VARCHAR(220),
    product_image TEXT,             
    description TEXT,
    size_detail JSON,                
    breadcrumbs JSON,                    
    hash_key VARCHAR(200),
    hash_key_pdp varchar(200) unique,
    INDEX set_index (designer_name)
    )engine=InnoDB charset=utf8mb4 collate=utf8mb4_unicode_ci"""
    cur.execute(query2)
    conn.commit()

    #table for storing pdp data
    query3 = f"""CREATE TABLE if not exists {pdp_data_table} (
    id int auto_increment PRIMARY KEY,
    product_name VARCHAR(250),
    product_url TEXT,
    product_price VARCHAR(100),
    product_mrp VARCHAR(100),
    discount_perc VARCHAR(50),
    currency VARCHAR(10),
    designer_name VARCHAR(255),
    product_image TEXT,
    description TEXT,
    features TEXT,
    size_and_fit TEXT,
    size_detail JSON,
    breadcrumbs json,
    hash_key_pdp VARCHAR(230),
    index search_index (product_name),
    constraint unique_value unique (hash_key_pdp)
    )engine=InnoDB charset=utf8mb4 collate=utf8mb4_unicode_ci"""
    cur.execute(query3)
    conn.commit()

create_table()





# ======================================================================================================================
"""CREATE TABLE unique_pdp_url (
SELECT * FROM plp_page_read_table WHERE id IN (
SELECT id FROM (
SELECT id, product_url ,ROW_NUMBER() OVER (PARTITION BY product_url ORDER BY id ASC) AS rn FROM `plp_page_read_table`
) tr 
WHERE tr.rn=1
)
)"""
#=======================================================================================================================