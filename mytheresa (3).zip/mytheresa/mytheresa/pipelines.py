# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
from mytheresa.items import *
import mytheresa.db_config as db

class MytheresaPipeline:
    conn, cur = db.connection_()

    def insert_record(self,item,table_name,query_table=None):
        try:
            flag = item.pop("flag")
        except Exception as e:
            print(e)
        try:
            id_ = item.pop("id")
        except Exception as e:
            print(e)
        keys = f"({', '.join(item.keys())})"
        values = tuple(item.values())
        placeholder = ", ".join(["%s"] * len(item))
        query = f"insert ignore into {table_name} {keys} values ({placeholder})"
        self.cur.execute(query,values)
        self.conn.commit()
        try:
            if query_table and query_table== db.plp_page_read_table:
                query = f"update {query_table} set status='done' where id={id_}"
                self.cur.execute(query)
                self.conn.commit()
            elif query_table and query_table == db.unique_pdp_url:
                query = f"update {query_table} set status='page_read_done' where id={id_}"
                self.cur.execute(query)
                self.conn.commit()
            else:
                pass
        except Exception as e:
            print(e)


    def process_item(self, item, spider):
        if isinstance(item,MytheresaItem):
            self.insert_record(item,db.category_table)
        if isinstance(item,MytheresaPlpPageSaveItem):
            self.insert_record(item,db.plp_page_save_detail_table)
        if isinstance(item,MytheresaPlpPageReadItem):
            self.insert_record(item,db.plp_page_read_table,db.plp_page_save_detail_table)
        if isinstance(item,MytheresaPdpPageReadItem):
            self.insert_record(item, db.pdp_data_table,db.unique_pdp_url)
        return item


