import json
import os.path
import logging
import hashlib
from mytheresa.items import *
import mytheresa.db_config as db
import scrapy
from scrapy.cmdline import execute

logging.basicConfig(filename=db.plp_data_logs_file,filemode='a',
                    format='%(asctime)s | %(levelname)s | %(filename)s:%(lineno)d | %(message)s',
                    level=logging.INFO,
                    datefmt="%Y-%m-%d %H:%M:%S")

class PlpDataSpider(scrapy.Spider):
    name = "plp_links"
    category_links_list = list()
    handle_http_status_list = [304,4299]

    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)

    def start_requests(self):
        if os.path.exists(db.main_page_path):
            logging.info("main page read..")
            yield scrapy.Request(url=f"file:///{db.main_page_path}",callback=self.parse)
        else:
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9',
                'cache-control': 'max-age=0',
                'priority': 'u=0, i',
                'sec-ch-ua': '"Chromium";v="146", "Not-A.Brand";v="24", "Google Chrome";v="146"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Windows"',
                'sec-fetch-dest': 'document',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'same-origin',
                'sec-fetch-user': '?1',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36',
            }
            yield scrapy.Request(url='https://www.mytheresa.com/',headers=headers,callback=self.parse)

    def parse(self, response):
        if response.status == 200:
            if os.path.exists(db.main_page_path):
                pass
            else:
                with open(db.main_page_path,"w",encoding="utf-8") as f:
                    f.write(response.body.decode('utf-8'))
                    logging.info("main page saved..")
            #category extraction ..
            json_response = response.xpath('//script[@type="text/javascript"][contains(text(),"_PRELOADED_STATE__")]/text()').get()
            try:
                category_links_dict = dict()
                json_data = json.loads(json_response.split("w.__PRELOADED_STATE__ = ")[-1].replace(";", "").strip())
                navigation_key = json_data.get("navigation",None).get("data",None).get("navigation",None)
                # yielding each category into parse_category for extracting category links
                main_category = list(navigation_key.keys())
                for main_cat in main_category:
                    logging.info("category list parse to parse_category function..")
                    yield from self.parse_category(navigation_key[main_cat],main_cat)
            except Exception as e:
                print("invalid json error or missing json..")

    def parse_category(self,main_category_list,main_cat):
        if main_category_list:
            for cat_value in main_category_list:
                level1_name = cat_value.get("label")
                level1_url = cat_value.get("location",{}).get("href",None)
                if level1_url:
                    level1_url = "https://www.mytheresa.com/us/en"+level1_url
                hash_key = hashlib.sha256(f"{main_cat}{level1_name}{level1_url}".encode()).hexdigest()
                cat_dict = MytheresaItem()
                cat_dict["main_cat_name"]=main_cat
                cat_dict["category_name"]=level1_name
                cat_dict["category_url"]=level1_url
                cat_dict["sub_cat_name"] = None
                cat_dict["sub_cat_url"] = None
                cat_dict["hash_key"]=hash_key
                cat_dict["parent_cat_id"] = 1
                cat_dict["level_id"] =2
                yield cat_dict
                for sub_category in cat_value["content"]:
                    if sub_category["hideInApp"] == "false" or sub_category["hideInApp"] == False:
                        for sub_cat in sub_category["items"]:
                            level2_name = sub_cat["label"]
                            leve2_url = "https://www.mytheresa.com/us/en"+sub_cat["location"]["href"]
                            hash_key = hashlib.sha256(f"{main_cat}{level1_name}{level1_url}{level2_name}{leve2_url}".encode()).hexdigest()
                            subcat_dict = MytheresaItem()
                            subcat_dict["main_cat_name"]= main_cat
                            subcat_dict["category_name"]=level1_name
                            subcat_dict["category_url"]= level1_url
                            subcat_dict["sub_cat_name"] = level2_name
                            subcat_dict["sub_cat_url"] = leve2_url
                            subcat_dict["hash_key"]= hash_key
                            subcat_dict["parent_cat_id"] = 2
                            subcat_dict["level_id"] = 3
                            yield subcat_dict
        else:
            logging.warning("main category list not found...")

if __name__ == "__main__":
    execute("scrapy crawl plp_links".split())