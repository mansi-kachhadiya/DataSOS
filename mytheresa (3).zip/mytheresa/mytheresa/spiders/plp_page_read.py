import hashlib
import json
from typing import Iterable, Any

import scrapy
import mytheresa.db_config as db
from mytheresa.items import *
from scrapy.cmdline import execute

class PlpPageReadSpider(scrapy.Spider):
    name = "plp_page_read"
    # allowed_domains = ["www.mytheresa.com"]
    # start_urls = ["https://www.mytheresa.com/us/en"]
    def __init__(self,start_,end,*args,**kwargs):
        super().__init__(*args,*kwargs)
        self.start_ = start_
        self.end = end

    def start_requests(self):
        conn, cur = db.connection_()
        query = f"select * from {db.plp_page_save_detail_table} where status='pending' and id between {self.start_} and {self.end}"
        cur.execute(query)
        records = cur.fetchall()
        try:
            for data in records:
                id_ = data["id"]
                main_cat_name = data["main_cat_name"]
                category_name = data["category_name"]
                category_url = data["category_url"]
                sub_cat_name = data["sub_cat_2_name"]
                sub_cat_url = data["sub_cat_2_url"]
                page_no = data["page_no"]
                page_save_path = data["page_save_path"]
                hash_key = data["hash_key"]
                cb_kwags_dict = {"id_":id_,"main_cat_name":main_cat_name, "category_name":category_name,
                                "category_url":category_url, "sub_cat_name":sub_cat_name,
                                "sub_cat_url":sub_cat_url,"page_no":page_no,"page_save_path":page_save_path,"hash_key":hash_key
                                 }

                yield scrapy.Request(url=f"file:///{page_save_path}",callback=self.parse,dont_filter=True,cb_kwargs=cb_kwags_dict)
        except Exception as e:
            print("issue in db start_request :",e)


        pass
    def parse(self, response,**kwargs):
        id_ = kwargs["id_"]
        main_cat_name = kwargs["main_cat_name"]
        category_name = kwargs["category_name"]
        category_url = kwargs["category_url"]
        sub_cat_name = kwargs["sub_cat_name"]
        sub_cat_url = kwargs["sub_cat_url"]
        page_no = kwargs["page_no"]
        page_save_path = kwargs["page_save_path"]
        hash_key = kwargs["hash_key"]

        try:
            response_json = json.loads(response.text)
            products_list = response_json.get("data",{}).get("xProductListingPage",{})
            #breadcrumb
            breadcrumb_list = list()
            breadcrumb= products_list.get("breadcrumb",[])
            if breadcrumb:
                for val in breadcrumb:
                    breadcrumb_list.append({
                        "name": val["name"],
                        "url": "https://www.mytheresa.com/us/en"+val["slug"]
                    })
            #product_scrape
            products_ = products_list.get("products",[])
            if products_:
                for products in products_:
                    #product_name
                    product_name = products.get("name",None)

                    #designer_name
                    designer_name = products.get("designer",None)

                    #description
                    description = products.get("description",None)

                    #images
                    images = " | ".join(products.get("displayImages",[]))

                    #curency code
                    currency = products.get("price",{}).get("currencyCode","USD")

                    #price
                    price = products.get("price",{}).get("original",None)
                    if price:
                        price = int(price / 100)

                    #product_url
                    product_url = fr"https://www.mytheresa.com/us/en/{main_cat_name}{products.get("slug")}"

                    #variation wise size and sku gathering
                    try:
                        variation_list = products.get("variants",[])
                        variation_data_list = list()
                        for variation in  variation_list:
                            variation_data_list.append({
                                "size": variation.get("size",None),
                                "sku":variation.get("sku",None),
                                "stock_status":variation.get("availability",{}).get("hasStock",None)
                            })
                    except Exception as e:
                        variation_data_list = []
                        print("no variation found...")
                    hash_key_pdp = hashlib.sha256(f"{product_name}{product_url}{hash_key}".encode()).hexdigest()
                    #inseret plp data in sql and update status in pipeline
                    try:
                        item = MytheresaPlpPageReadItem()
                        item["id"] = id_
                        item["product_name"] =product_name
                        item["product_url"] = product_url
                        item["product_price"] = price
                        item["currency"] = currency
                        item["designer_name"] = designer_name
                        item["product_image"] = images
                        item["description"] = description
                        item["size_detail"] = json.dumps(variation_data_list)
                        item["breadcrumbs"] = json.dumps(breadcrumb_list)
                        item["hash_key"] = hash_key
                        item["hash_key_pdp"] = hash_key_pdp
                        yield item
                    except Exception as e:
                        print("error in insertion :",e)
            else: print("Product count : 0")

        except Exception as e:
            print("parsing error :",e)

if __name__ == "__main__":
    execute("scrapy crawl plp_page_read -a start_=1 -a end=5000".split())