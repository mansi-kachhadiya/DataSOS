import json
import os.path,os
import logging
import time
import mytheresa.db_config as db
import hashlib
from mytheresa.items import *
import mytheresa.db_config as db
import scrapy
from scrapy.cmdline import execute
class PlpDataSpider(scrapy.Spider):
    name = "plp_data"
    allowed_domains = ["www.mytheresa.com"]
    handle_http_status_list = [304,4299]
    headers = {
        'accept': '*/*',
        'accept-language': 'en',
        'content-type': 'text/plain;charset=UTF-8',
        'origin': 'https://www.mytheresa.com',
        'priority': 'u=1, i',
        'referer': f'',
        'sec-ch-ua': '"Chromium";v="146", "Not-A.Brand";v="24", "Google Chrome";v="146"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36',
        'x-country': 'US',
        'x-geo': 'US',
        'x-nsu': 'false',
        'x-op': 'ntr',
        'x-region': 'DC',
        'x-section': 'women',
        'x-store': 'US',

    }
    jdata = '{"query":"query XProductListingPageQuery($filtersQueryParams: String, $page: Int, $size: Int, $slug: String, $sort: String) {\\n  xProductListingPage: xProductListingPageV2(filtersQueryParams: $filtersQueryParams, page: $page, size: $size, slug: $slug, sort: $sort) {\\n    id\\n    alternateUrls {\\n      language\\n      store\\n      url\\n    }\\n    breadcrumb {\\n      id\\n      name\\n      slug\\n    }\\n    combinedDepartmentGroupAndCategoryErpID\\n    department\\n    designerErpId\\n    displayName\\n    isMonetisationExcluded\\n    isSalePage\\n    pagination {\\n      ...paginationData\\n    }\\n    products {\\n      ...productData\\n    }\\n    sort {\\n      currentParam\\n      params\\n    }\\n    facets\\n  }\\n}\\n\\nfragment paginationData on XPagination {\\n  currentPage\\n  itemsPerPage\\n  totalItems\\n  totalPages\\n}\\n\\nfragment priceData on XSharedPrice {\\n  currencyCode\\n  currencySymbol\\n  discount\\n  discountEur\\n  extraDiscount\\n  finalDuties\\n  hint\\n  includesVAT\\n  isPriceModifiedByRegionalRules\\n  original\\n  originalDuties\\n  originalDutiesEur\\n  originalEur\\n  percentage\\n  regionalRulesModifications {\\n    priceColor\\n  }\\n  regular\\n  vatPercentage\\n}\\n\\nfragment productData on XSharedProduct {\\n  color\\n  combinedCategoryErpID\\n  combinedCategoryName\\n  department\\n  description\\n  designer\\n  designerErpId\\n  designerInfo {\\n    designerId\\n    displayName\\n    slug\\n  }\\n  displayImages\\n  enabled\\n  features\\n  fta\\n  hasMultipleSizes\\n  hasSizeChart\\n  hasStock\\n  isComingSoon\\n  isInWishlist\\n  isPurchasable\\n  isSizeRelevant\\n  labelObjects {\\n    id\\n    label\\n  }\\n  labels\\n  mainPrice\\n  mainWaregroup\\n  name\\n  price {\\n    ...priceData\\n  }\\n  priceDescription\\n  promotionLabels {\\n    label\\n    type\\n  }\\n  seasonCode\\n  sellerOrigin\\n  sets\\n  sizeAndFit\\n  sizesOnStock\\n  sizeTag\\n  sizeType\\n  sku\\n  slug\\n  trackingMetadata {\\n    key\\n    value\\n  }\\n  variants {\\n    allVariants {\\n      availability {\\n        hasStock\\n        lastStockQuantityHint\\n      }\\n      isInWishlist\\n      size\\n      sizeHarmonized\\n      sku\\n    }\\n    availability {\\n      hasStock\\n      lastStockQuantityHint\\n    }\\n    isInWishlist\\n    price {\\n      currencyCode\\n      currencySymbol\\n      discount\\n      discountEur\\n      extraDiscount\\n      includesVAT\\n      isPriceModifiedByRegionalRules\\n      original\\n      originalEur\\n      percentage\\n      regionalRulesModifications {\\n        priceColor\\n      }\\n      vatPercentage\\n    }\\n    size\\n    sizeHarmonized\\n    sku\\n  }\\n}\\n","variables":{"page":6,"size":60,"slug":"/edits/bridal","sort":null,"filtersQueryParams":""}}'

    conn, cur = db.connection_()
    # start_urls = ["https://www.mytheresa.com/us/en"]
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)

    def start_requests(self):
        query = f'SELECT * FROM {db.category_table} WHERE sub_cat_name IS NULL AND main_cat_name="women" AND STATUS="main_cat"'
        self.cur.execute(query)
        records = self.cur.fetchall()

        sub_cat_query = f"SELECT * FROM {db.category_table} WHERE main_cat_name='women' AND sub_cat_name IS NOT NULL AND STATUS='rerun'"
        self.cur.execute(sub_cat_query)
        sub_records = self.cur.fetchall()
        # for data in records:
        #     page = 1
        #     main_category = data["main_cat_name"]
        #     sub_category = data['category_name']
        #     category_url = data["category_url"]
        #     sub_cat_2_name = data["sub_cat_name"]
        #     sub_cat_2_url = data["sub_cat_url"]
        #     self.headers["referer"] = category_url
        #     json_data = json.loads(self.jdata)
        #     json_data["variables"]["page"] = page
        #     slug = category_url.split(f"{main_category}")[-1]
        #     json_data["variables"]["slug"] = slug
        #     json_data = json.dumps(json_data)
        #     pagesave_plp = fr"G:\pagesave\MYTHERESA\plp_pagesave\{db.current_year_month}\{main_category}\{sub_category}"
        #
        #     yield scrapy.Request(url="https://www.mytheresa.com/api",method="post",
        #                          headers=self.headers, body=json_data,callback=self.parse,
        #                          cb_kwargs={"page":page,"main_category":main_category,
        #                                     "sub_category":sub_category,"category_url":category_url,
        #                                     "sub_cat_2_name":sub_cat_2_name,"sub_cat_2_url":sub_cat_2_url,"pagesave_plp":pagesave_plp,"flag":"cat_page"})
        # time.sleep(5)
        for sub_data in sub_records:
            page = 1
            main_category = sub_data["main_cat_name"]
            sub_category = sub_data['category_name']
            category_url = sub_data["category_url"]
            sub_cat_2_name = sub_data["sub_cat_name"]
            sub_cat_2_url = sub_data["sub_cat_url"]
            self.headers["referer"] = sub_cat_2_url
            json_data = json.loads(self.jdata)
            json_data["variables"]["page"] = page
            if "?" in sub_cat_2_url:
                slug = sub_cat_2_url.split(f"{main_category}")[-1].split("?")[0]
                filtersQueryParams = sub_cat_2_url.split("?")[-1]
                json_data["filtersQueryParams"] = filtersQueryParams
            else:
                slug = sub_cat_2_url.split(f"{main_category}")[-1]
            json_data["variables"]["slug"] = slug
            json_data = json.dumps(json_data)
            pagesave_plp = fr"G:\pagesave\MYTHERESA\plp_pagesave\{db.current_year_month}\{main_category}\{sub_category}\{sub_cat_2_name}"
            yield scrapy.Request(url="https://www.mytheresa.com/api", method="post",
                                 headers=self.headers, body=json_data, callback=self.parse,
                                 cb_kwargs={"page": page, "main_category": main_category,
                                            "sub_category": sub_category, "category_url": category_url,
                                            "sub_cat_2_name": sub_cat_2_name, "sub_cat_2_url": sub_cat_2_url,
                                            "pagesave_plp":pagesave_plp,"flag":"subcat_page"})

    def parse(self, response,**kwargs):
        page = kwargs["page"]
        main_category = kwargs["main_category"]
        category_url = kwargs["category_url"]
        sub_category = kwargs["sub_category"]
        sub_cat_2_name = kwargs["sub_cat_2_name"]
        sub_cat_2_url = kwargs["sub_cat_2_url"]
        pagesave_plp = kwargs["pagesave_plp"]
        flag = kwargs["flag"]
        if response.status==200:
            data = response.json()
            print("response found...")
            os.makedirs(fr"G:\pagesave\MYTHERESA\plp_pagesave\{db.current_year_month}",exist_ok=True)
            # hash_key = hashlib.sha256(pagesave_plp.encode()).hexdigest()
            hash_key = hashlib.sha256(fr"{pagesave_plp}\page_{page}".encode()).hexdigest()
            page_save_path = fr"G:\pagesave\MYTHERESA\plp_pagesave\{db.current_year_month}\{hash_key}.json"

            with open(page_save_path,"w",encoding="utf-8") as f:
                json.dump(data,f,ensure_ascii=False,indent=4)
            try:
                item = MytheresaPlpPageSaveItem()
                item["main_cat_name"]=main_category
                item["category_name"] = sub_category
                item["category_url"] = category_url
                item["sub_cat_2_name"] = sub_cat_2_name
                item["sub_cat_2_url"] = sub_cat_2_url
                item["page_no"] = page
                item["page_save_path"] = page_save_path
                item["hash_key"] = hash_key
                item["flag"] = flag
                yield item
            except Exception as e:
                print("error in parse function",e)
            try:
                current_page = data.get("data",None).get("xProductListingPage",None).get("pagination",None).get("currentPage",None)
                total_page = data.get("data",None).get("xProductListingPage",None).get("pagination",None).get("totalPages",None)
                for i in range(total_page-1):
                    if not data.get("data", None).get("xProductListingPage", None).get("products", None):
                        break
                    page+=1
                    if flag =="cat_page":
                        self.headers["referer"] = category_url
                        json_data = json.loads(self.jdata)
                        json_data["variables"]["page"] = page
                        slug = category_url.split(f"{main_category}")[-1]
                        json_data["variables"]["slug"] = slug
                        json_data = json.dumps(json_data)
                        yield scrapy.Request(url="https://www.mytheresa.com/api", method="post",
                                             headers=self.headers, body=json_data, callback=self.pagination_request,
                                             cb_kwargs={"page": page, "main_category": main_category,
                                                        "sub_category": sub_category, "category_url": category_url,
                                                        "sub_cat_2_name": sub_cat_2_name,
                                                        "sub_cat_2_url": sub_cat_2_url, "pagesave_plp": pagesave_plp,
                                                        "flag": "cat_page"})

                    else:
                        self.headers["referer"] = sub_cat_2_url
                        json_data = json.loads(self.jdata)
                        json_data["variables"]["page"] = page
                        if "?" in sub_cat_2_url:
                            slug = sub_cat_2_url.split(f"{main_category}")[-1].split("?")[0]
                            filtersQueryParams = sub_cat_2_url.split("?")[-1]
                            json_data["filtersQueryParams"] = filtersQueryParams
                        else:
                            slug = sub_cat_2_url.split(f"{main_category}")[-1]
                        json_data["variables"]["slug"] = slug
                        json_data = json.dumps(json_data)
                        yield scrapy.Request(url="https://www.mytheresa.com/api", method="post",
                                             headers=self.headers, body=json_data, callback=self.pagination_request,
                                             cb_kwargs={"page": page, "main_category": main_category,
                                                        "sub_category": sub_category, "category_url": category_url,
                                                        "sub_cat_2_name":sub_cat_2_name,"sub_cat_2_url":sub_cat_2_url,"pagesave_plp":pagesave_plp,"flag":"subcat_page"})

            except Exception as e:
                print("error in pagination loop in parse",e)

        else:
            print("==========response issue found===========")

    def pagination_request(self,response,**kwargs):
        page = kwargs["page"]
        main_category = kwargs["main_category"]
        category_url = kwargs["category_url"]
        sub_category = kwargs["sub_category"]
        sub_cat_2_name = kwargs["sub_cat_2_name"]
        sub_cat_2_url = kwargs["sub_cat_2_url"]
        pagesave_plp = kwargs["pagesave_plp"]
        flag = kwargs["flag"]
        if response.status==200:
            data = response.json()
            print("response found...")
            os.makedirs(pagesave_plp,exist_ok=True)
            # =============================================
            hash_key = hashlib.sha256(fr"{pagesave_plp}\page_{page}".encode()).hexdigest()
            page_save_path = fr"G:\pagesave\MYTHERESA\plp_pagesave\{db.current_year_month}\{hash_key}.json"

            with open(page_save_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=4)
            # =============================================
            try:
                item = MytheresaPlpPageSaveItem()
                item["main_cat_name"]=main_category
                item["category_name"] = sub_category
                item["category_url"] = category_url
                item["sub_cat_2_name"] = sub_cat_2_name
                item["sub_cat_2_url"] = sub_cat_2_url
                item["page_no"] = page
                item["page_save_path"] = page_save_path
                item["hash_key"] = hash_key
                item["flag"] = flag
                yield item
            except Exception as e:
                print("error in pagination request function:",e)
            try:
                current_page = data.get("data",None).get("xProductListingPage",None).get("pagination",None).get("currentPage",None)
                total_page = data.get("data",None).get("xProductListingPage",None).get("pagination",None).get("totalPages",None)
                if not data.get("data", None).get("xProductListingPage", None).get("products", None):
                    return None
            except Exception as e:
                print(e)



if __name__ == "__main__":
    execute("scrapy crawl plp_data".split())