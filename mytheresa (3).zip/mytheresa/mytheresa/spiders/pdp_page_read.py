import json
from re import match

import scrapy
from scrapy.cmdline import execute
import mytheresa.db_config as db
from mytheresa.items import *
import os
import re
from datetime import datetime

class PdpPageReadSpider(scrapy.Spider):
    name = "pdp_page_read"
    # allowed_domains = ["www.mytheresa.com"]
    # start_urls = ["https://www.mytheresa.com/us/en"]
    conn, cur = db.connection_()
    def __init__(self,start_,end,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.start_ = start_
        self.end = end

    def start_requests(self):
        pdp_pagesave_path = fr"G:/pagesave/MYTHERESA/pdp_pagesave/202604"
        query = f"select * from {db.unique_pdp_url} where status='done' and id between {self.start_} and {self.end}"
        self.cur.execute(query)
        records = self.cur.fetchall()
        if records:
            for data in records:
                id_ = data["id"]
                product_url = data["product_url"]
                hash_key_pdp = data["hash_key_pdp"]
                breadcrumbs = data["breadcrumbs"]
                file_path = fr"{pdp_pagesave_path}/{hash_key_pdp}.html"
                yield scrapy.Request(url = f"file:///{file_path}",callback=self.parse,dont_filter=True,
                                     cb_kwargs={"id_":id_,
                                                "product_url":product_url,
                                                "breadcrumbs":breadcrumbs,
                                                "hash_key_pdp":hash_key_pdp,
                                                "file_path":file_path})
    def parse(self, response,**kwargs):
        id_ = kwargs['id_']
        product_url = kwargs["product_url"]
        hash_key_pdp = kwargs["hash_key_pdp"]
        breadcrumbs = kwargs["breadcrumbs"]

        json_path = response.xpath('//script[@type="text/javascript"][contains(text(),"window.__PRELOADED_STATE__")]//text()').get()
        if json_path:
            try:
                json_data = json_path.split("window.__PRELOADED_STATE__ = ")[-1].rstrip(";\r\n    ")
            except Exception as e:
                match = re.search(r'window\.__PRELOADED_STATE__\s*=\s*(\{.*?\});',json_path,re.DOTALL)
                json_data = match.group(1) if match else None
            json_response = json.loads(json_data)
            data = json_response.get("pdp",{}).get("content",{}).get("data",{})
            # breadcrumbs
            breadcrumbs_list = data.get("breadcrumb",[])
            if breadcrumbs_list:
                brd_lst = list()
                #[{"url": "https://www.mytheresa.com/us/en/women", "name": "Women"}, {"url": "https://www.mytheresa.com/us/en/women/clothing", "name": "Clothing"}, {"url": "https://www.mytheresa.com/us/en/women/clothing/tops", "name": "Tops"}]
                for list_ in breadcrumbs_list:
                    brd_lst.append({"url":"https://www.mytheresa.com/us/en"+list_.get("slug"),
                                    "name":list_.get("name")})
                breadcrumbs = json.dumps(brd_lst)

            #designer
            designer = data.get("designer",None)

            #name
            product_name = data.get("name",None)

            #mrp
            mrp = data.get("price",{}).get("original",None)

            #discounted price /
            price = data.get("price",{}).get("discount",None)

            #discout per %
            discount_per = data.get("price",{}).get("percentage",None)

            #price filtering
            if mrp and price and discount_per:
                mrp = int(mrp / 100)
                price = int(price / 100)
                discount_per = discount_per.replace("%","")
            if mrp and price and not discount_per:
                mrp = int(mrp / 100)
                price = int(price / 100)

            #description
            description = data.get("description",None)

            #features
            features = None
            features_list = data.get("features",[])
            if features_list and len(features_list) > 1:
                features = ",".join(features_list)
            elif features_list:
                features = "".join(features_list)

            #size and fit
            size_and_fit = None
            size_fit_list = data.get("sizeAndFit",[])
            if size_fit_list and len(size_fit_list)>1:
                size_and_fit = ",".join(size_fit_list)
            elif size_and_fit:
                size_and_fit = "".join(size_fit_list)

            #images
            images = data.get("displayImages",[])
            images = " | ".join(images) if images else None

            # variation wise size and sku gathering
            try:
                variation_list = data.get("variants", [])
                variation_data_list = list()
                for variation in variation_list:
                    variation_data_list.append({
                        "size": variation.get("size", None),
                        "sku": variation.get("sku", None),
                        "stock_status": variation.get("availability", {}).get("hasStock", None)
                    })
            except Exception as e:
                variation_data_list = []
                print("no variation found...")

            try:
                item = MytheresaPdpPageReadItem()
                item["id"] = id_
                item["product_name"] = product_name
                item["product_url"] = product_url
                item["product_price"] = price
                item["product_mrp"] = mrp
                item["Discount_perc"] = discount_per
                item["currency"] = "USD"
                item["designer_name"] = designer
                item["product_image"] = images
                item["description"] = description
                item["features"] = features
                item["size_and_fit"] = size_and_fit
                item["size_detail"] = json.dumps(variation_data_list)
                item["breadcrumbs"] = breadcrumbs
                item["hash_key_pdp"] = hash_key_pdp
                yield item
            except Exception as e:
                print("error in insertion :", e)










if __name__ == "__main__":
    execute("scrapy crawl pdp_page_read -a start_=5771 -a end=6000".split())