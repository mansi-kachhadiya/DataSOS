import mytheresa.db_config as db
import json
conn , cur = db.connection_()
batch_size = 150
last_id = 0
bat_lines = list()
while True:
    query = f"select id from {db.plp_page_save_detail_table} where status='pending' and id > {last_id} order by id asc limit {batch_size}"
    cur.execute(query)
    rows = cur.fetchall()
    if not rows:break
    start = rows[0]["id"]
    end = rows[-1]["id"]
    bat_lines.append(f'start "{start}-{end}" scrapy crawl plp_page_read -a start_={start} -a end={end}\n')
    last_id = end

with open("G:\Mansi\projects\scrapy_project\mytheresa\ bat_files\plp_read_bat.bat","w") as f:
    for line in bat_lines:
        f.write(line)
print("bat file created : file pah == G:\Mansi\projects\scrapy_project\mytheresa\ bat_files\plp_read_bat.bat")


