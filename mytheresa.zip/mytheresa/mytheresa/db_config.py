import pymysql
#plp_data
#this page save data of home page to get 4  listed category (women,man,kids,life)
main_page_path = fr"G:\pagesave\MYTHERESA\category_name_pages\main_page.html"
plp_data_logs_file = fr"G:\Mansi\projects\scrapy_project\mytheresa\logs\plp_data_logs.txt"

category_table = "category_listing_table"

conn = pymysql.connect(host="localhost",user='root')
cur = conn.cursor()
cur.execute("create database if not exists mytheresa")
conn.commit()
conn.close()
def connection_():
    conn = pymysql.connect(host="localhost",user='root',database='mytheresa',cursorclass=pymysql.cursors.DictCursor)
    cur = conn.cursor()
    return conn, cur

def create_table(table_name):
    conn, cur = connection_()
    query = f"""create table if not exists {table_name} (
    id int auto_increment primary key,
    main_cat_name varchar(100),
    category_name varchar(200),
    category_url text,
    hash_key varchar(200),
    parent_cat_id int(40),
    level_id int(40),
    status varchar(150) default 'pending',
    index cat_index (category_name,hash_key),
    constraint unique_value unique (hash_key)
    )engine=InnoDB charset=utf8mb4 collate=utf8mb4_unicode_ci"""
    cur.execute(query)
    conn.commit()

create_table(category_table)