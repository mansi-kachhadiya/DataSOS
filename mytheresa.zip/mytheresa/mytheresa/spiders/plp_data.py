import json
import os.path,os
import logging
import hashlib
from mytheresa.items import *
import mytheresa.db_config as db
import scrapy
from scrapy.cmdline import execute
class PlpDataSpider(scrapy.Spider):
    name = "plp_data"
    allowed_domains = ["www.mytheresa.com"]
    handle_http_status_list = [304,4299]

    conn, cur = db.connection_()
    # start_urls = ["https://www.mytheresa.com/us/en"]
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)

    def start_requests(self):
        query = f"select * from {db.category_table} where main_cat_name='women' and status='pending'"
        self.cur.execute(query)
        records = self.cur.fetchall()
        for data in records:
            page = 1
            main_category = data["main_cat_name"]
            sub_category = data['category_name']
            category_url = data["category_url"]
            headers = {
                'accept': '*/*',
                'accept-language': 'en',
                'content-type': 'text/plain;charset=UTF-8',
                'origin': 'https://www.mytheresa.com',
                'priority': 'u=1, i',
                'referer': f'{category_url}',
                'sec-ch-ua': '"Chromium";v="146", "Not-A.Brand";v="24", "Google Chrome";v="146"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Windows"',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'same-origin',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36',
                'x-country': 'US',
                'x-geo': 'US',
                'x-nsu': 'false',
                'x-op': 'ntr',
                'x-region': 'DC',
                'x-section': 'women',
                'x-store': 'US',

            }
            data = '{"query":"query XProductListingPageQuery($filtersQueryParams: String, $page: Int, $size: Int, $slug: String, $sort: String) {\\n  xProductListingPage: xProductListingPageV2(filtersQueryParams: $filtersQueryParams, page: $page, size: $size, slug: $slug, sort: $sort) {\\n    id\\n    alternateUrls {\\n      language\\n      store\\n      url\\n    }\\n    breadcrumb {\\n      id\\n      name\\n      slug\\n    }\\n    combinedDepartmentGroupAndCategoryErpID\\n    department\\n    designerErpId\\n    displayName\\n    isMonetisationExcluded\\n    isSalePage\\n    pagination {\\n      ...paginationData\\n    }\\n    products {\\n      ...productData\\n    }\\n    sort {\\n      currentParam\\n      params\\n    }\\n    facets\\n  }\\n}\\n\\nfragment paginationData on XPagination {\\n  currentPage\\n  itemsPerPage\\n  totalItems\\n  totalPages\\n}\\n\\nfragment priceData on XSharedPrice {\\n  currencyCode\\n  currencySymbol\\n  discount\\n  discountEur\\n  extraDiscount\\n  finalDuties\\n  hint\\n  includesVAT\\n  isPriceModifiedByRegionalRules\\n  original\\n  originalDuties\\n  originalDutiesEur\\n  originalEur\\n  percentage\\n  regionalRulesModifications {\\n    priceColor\\n  }\\n  regular\\n  vatPercentage\\n}\\n\\nfragment productData on XSharedProduct {\\n  color\\n  combinedCategoryErpID\\n  combinedCategoryName\\n  department\\n  description\\n  designer\\n  designerErpId\\n  designerInfo {\\n    designerId\\n    displayName\\n    slug\\n  }\\n  displayImages\\n  enabled\\n  features\\n  fta\\n  hasMultipleSizes\\n  hasSizeChart\\n  hasStock\\n  isComingSoon\\n  isInWishlist\\n  isPurchasable\\n  isSizeRelevant\\n  labelObjects {\\n    id\\n    label\\n  }\\n  labels\\n  mainPrice\\n  mainWaregroup\\n  name\\n  price {\\n    ...priceData\\n  }\\n  priceDescription\\n  promotionLabels {\\n    label\\n    type\\n  }\\n  seasonCode\\n  sellerOrigin\\n  sets\\n  sizeAndFit\\n  sizesOnStock\\n  sizeTag\\n  sizeType\\n  sku\\n  slug\\n  trackingMetadata {\\n    key\\n    value\\n  }\\n  variants {\\n    allVariants {\\n      availability {\\n        hasStock\\n        lastStockQuantityHint\\n      }\\n      isInWishlist\\n      size\\n      sizeHarmonized\\n      sku\\n    }\\n    availability {\\n      hasStock\\n      lastStockQuantityHint\\n    }\\n    isInWishlist\\n    price {\\n      currencyCode\\n      currencySymbol\\n      discount\\n      discountEur\\n      extraDiscount\\n      includesVAT\\n      isPriceModifiedByRegionalRules\\n      original\\n      originalEur\\n      percentage\\n      regionalRulesModifications {\\n        priceColor\\n      }\\n      vatPercentage\\n    }\\n    size\\n    sizeHarmonized\\n    sku\\n  }\\n}\\n","variables":{"page":6,"size":60,"slug":"/edits/bridal","sort":null,"filtersQueryParams":""}}'
            json_data = json.loads(data)
            json_data["variables"]["page"] = page
            slug = category_url.split("women")[-1]
            json_data["variables"]["slug"] = slug
            json_data = json.dumps(json_data)
            yield scrapy.Request(url="https://www.mytheresa.com/api",method="post", headers=headers, body=json_data,callback=self.parse)
            break



    def parse(self, response):
        if response.status==200:
            print("response found...")


if __name__ == "__main__":
    execute("scrapy crawl plp_data".split())