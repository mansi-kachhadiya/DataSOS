# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
from mytheresa.items import *
import mytheresa.db_config as db

class MytheresaPipeline:
    conn, cur = db.connection_()

    def insert_record(self,item,table_name):
        keys = f"({', '.join(item.keys())})"
        values = tuple(item.values())
        placeholder = ", ".join(["%s"] * len(item))
        query = f"insert ignore into {table_name} {keys} values ({placeholder})"
        self.cur.execute(query,values)
        self.conn.commit()

    def process_item(self, item, spider):
        if isinstance(item,MytheresaItem):
            self.insert_record(item,db.category_table)
        return item


