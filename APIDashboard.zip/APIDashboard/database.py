from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker,declarative_base

engine = create_engine("abc_Database connection string",connect_args={"check_Same_thread":False})
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()