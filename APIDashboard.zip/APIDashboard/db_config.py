# db_config.py
import os
import pymysql
from datetime import datetime
import random
import re
# ---- Date based table & folder ----
TODAY = datetime.now().strftime("%Y%m")
TABLE_NAME = f"URL_Tracking_{TODAY}"
BASE_PATH = os.path.normpath(r"E:/pagesave")
SAVE_PATH = os.path.join(BASE_PATH, TODAY)
os.makedirs(SAVE_PATH, exist_ok=True)

# # ---- DB Connection ----
def get_connection():
    con = pymysql.connect(
        host="localhost",
        user="root",
        # password="sa123$",
        database="feasibility_test",
        autocommit=True
    )
    return con, con.cursor()


# ---- Create Table ----
def create_table():
    con, cur = get_connection()

    query = f"""
    CREATE TABLE IF NOT EXISTS {TABLE_NAME} (
        id INT AUTO_INCREMENT PRIMARY KEY,
        status VARCHAR(50),
        url TEXT,
        req_type VARCHAR(50),
        pagesave TEXT,
        timestamp_time VARCHAR(255),
        file_hash_key TEXT
    )
    """
    cur.execute(query)
    cur.close()
    con.close()

create_table()
# ---- Insert Record ----
def insert_records(item: dict):

    con, cur = get_connection()

    columns = ", ".join(item.keys())
    placeholders = ", ".join(["%s"] * len(item))

    query = f"""INSERT INTO {TABLE_NAME} ({columns}) VALUES ({placeholders})"""

    cur.execute(query, tuple(item.values()))
    con.commit()
    cur.close()
    con.close()


USER_AGENTS = [
    # Chrome
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36",
    # Firefox
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0",
    # Edge
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0",
    # Safari
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_3) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15",
    # Opera
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 OPR/109.0.0.0",
    #brave
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36",
    #macos
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_3) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36"
]

def build_headers():
    ua = random.choice(USER_AGENTS)
    headers = {
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "accept-language": random.choice([
            "en-US,en;q=0.9",
            "en-GB,en;q=0.8",
        ]),
        "upgrade-insecure-requests": "1",
        "user-agent": ua,
    }
    # If Chrome
    if "Chrome" in ua and "Chromium" not in ua:
        chrome_version = re.search(r"Chrome/(\d+)", ua).group(1)
        headers.update({
            "sec-ch-ua": f'"Not:A-Brand";v="99", "Google Chrome";v="{chrome_version}", "Chromium";v="{chrome_version}"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "document",
            "sec-fetch-mode": "navigate",
            "sec-fetch-site": "none",
        })
    return headers

