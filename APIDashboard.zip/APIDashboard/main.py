from datetime import datetime, timedelta
from typing import Any
import bcrypt
import jwt
from fastapi import Depends,HTTPException, Security, status
from fastapi.security import OAuth2PasswordBearer, SecurityScopes
from fastapi.testclient import TestClient
from pydantic import BaseModel
import  db_config as db
import hashlib
import json
from threading_request_check import *
from fastapi import FastAPI, Form ,Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from database import engine, Base, SessionLocal
from models import User
from auth import create_token, role_required
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
import uvicorn
import random
import os
from fastapi.middleware.cors import CORSMiddleware

fake_users = [
    {
        "id": 1,
        "username": "manager1",
        "password": bcrypt.hashpw("123".encode(), bcrypt.gensalt()).decode(),
        "role": "manager"
    },
    {
        "id": 2,
        "username": "dev1",
        "password": bcrypt.hashpw("123".encode(), bcrypt.gensalt()).decode(),
        "role": "developer"
    },
    {
        "id": 3,
        "username": "qa1",
        "password": bcrypt.hashpw("123".encode(), bcrypt.gensalt()).decode(),
        "role": "QA"
    }
]

class UserBase(BaseModel):
    username: str
    password: str

class LoginData(UserBase):
    pass

class PyUser(UserBase):
    id: int
    role: str

class Token(BaseModel):
    access_token: str
    token_type: str

app = FastAPI()
# Serve static folder
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

Base.metadata.create_all(bind=engine)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # allow all (for testing)
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

oauth_scheme = OAuth2PasswordBearer(
    tokenUrl="token",
    scopes={'items': 'permissions to access items'}
)

def authenticate_user(username: str, password: str) -> PyUser:
    for obj in fake_users:
        if obj['username'] == username:
            if not bcrypt.checkpw(password.encode(), obj['password'].encode()):
                raise HTTPException(status_code=401, detail="Invalid credentials")
            return PyUser(**obj)
    raise HTTPException(status_code=401, detail="Invalid credentials")

def create_token(user: PyUser) -> str:
    payload = {
        'sub': user.username,
        'role': user.role,
        'exp': datetime.utcnow() + timedelta(minutes=90)
    }
    token = jwt.encode(payload, key='secret', algorithm="HS256")
    return token

class RoleChecker:
    def __init__(self, allowed_roles: list[str]):
        self.allowed_roles = allowed_roles
    def __call__(self, token: str = Depends(oauth_scheme)):
        payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        user_role = payload.get("role")
        if user_role not in self.allowed_roles:
            raise HTTPException(
                status_code=403,
                detail="Access denied"
            )
        return payload
def create_token(user: PyUser) -> str:
    payload = {'sub': user.username, 'iat': datetime.utcnow(),
               'exp': datetime.utcnow() + timedelta(minutes=90)}
    token = jwt.encode(payload, key='secret')
    return token

@app.post('/token')
def login(login_data: LoginData) -> Token:
    user = authenticate_user(**login_data.dict())
    token_str = create_token(user)
    token = Token(access_token=token_str, token_type='bearer')
    return token


#resigster
@app.get("/register", response_class=HTMLResponse)
def register_page(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})

@app.post("/register")
def register(
    username: str = Form(...),
    password: str = Form(...),
    role: str = Form(...)
):
    hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()

    new_user = {
        "id": len(fake_users) + 1,
        "username": username,
        "password": hashed,
        "role": role
    }

    fake_users.append(new_user)

    return {"message": "User registered"}
#login route
def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.post("/login")
def login(username: str = Form(...), password: str = Form(...)):
    db = SessionLocal()
    user = db.query(User).filter(User.username == username).first()

    if not user:
        return {"error": "Invalid user"}

    if not bcrypt.checkpw(password.encode(), user.password_hash.encode()):
        return {"error": "Wrong password"}

    token = create_token(user)
    return {"access_token": token}

#api endpoint logic for basic functionality
@app.get("/")
def serve_ui():
    return FileResponse("static/basic_html.html")
@app.get("/dashboard")
def dashboard(user=Depends(role_required(["manager", "developer"]))):
    return {"message": "Welcome to dashboard"}
@app.get("/srp")
def req_pdp(url : str,user = Depends(RoleChecker(["manager", "developer"]))):
    ''' srp = simple request pdp '''
    import requests
    headers = db.build_headers()
    request_args = {"headers":headers}
    file_path = os.path.join(db.SAVE_PATH, "srp")
    os.makedirs(file_path, exist_ok=True)

    request_args = {k: v for k,v in request_args.items() if v is not None}
    try:
        response = requests.get(url,**request_args)
        if response.status_code == 200:
            file_hash_key = hashlib.sha256(f"200{url}srp{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
            pagesave_path = os.path.join(file_path,f"{file_hash_key}.html")
            # pagesave_path = os.path.join(file_path,f"{file_hash_key}.html")
            item = {"status":200,
                    "url":url,
                    "req_type":"srp",
                    "pagesave":pagesave_path,
                    "timestamp_time" : datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                    "file_hash_key":file_hash_key
            }

            with open(pagesave_path, "w", encoding="utf-8") as f:
                f.write(response.text)
            db.insert_records(item)
            return item
        else:
            file_hash_key = hashlib.sha256(f"{response.status_code}{url}srp{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
            pagesave_path = os.path.normpath(os.path.join(file_path,f"{file_hash_key}.html"))
            item = {
                    "status": response.status_code,
                    "url": url,
                    "req_type": "srp",
                    "pagesave":None,
                    "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                    "file_hash_key": file_hash_key
            }
            # with open(pagesave_path, "w", encoding="utf-8") as f:
            #     f.write(response.text)
            db.insert_records(item)
            return item
    except Exception as e:
        return {
            "status_code":500,
            "content":{"status": "error", "message": str(e)}
        }

@app.get("/srsp")
def req_sesion_pdp(url : str):

    """srsp = simple request session pdp"""
    import requests
    headers = db.build_headers()
    request_args = {"headers": headers}
    file_path = os.path.join(db.SAVE_PATH, "srsp")
    os.makedirs(file_path, exist_ok=True)
    request_args = {k: v for k, v in request_args.items() if v is not None}
    try:
        session = requests.Session()
        response = session.get(url, **request_args)
        session.close()
        if response.status_code == 200:
            file_hash_key = hashlib.sha256(
                f"200{url}srsp{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
            pagesave_path = os.path.join(file_path,f"{file_hash_key}.html")
            item = {"status": 200,
                    "url": url,
                    "req_type": "srsp",
                    "pagesave": pagesave_path,
                    "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                    "file_hash_key": file_hash_key
                    }

            with open(pagesave_path, "w", encoding="utf-8") as f:
                f.write(response.text)
            db.insert_records(item)
            return item
        else:
            file_hash_key = hashlib.sha256(
                f"{response.status_code}{url}srsp{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
            pagesave_path = os.path.join(file_path,f"{file_hash_key}.html")
            item = {
                "status": response.status_code,
                "url": url,
                "req_type": "srsp",
                "pagesave": None,
                "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                "file_hash_key": file_hash_key
            }
            # with open(pagesave_path, "w", encoding="utf-8") as f:
            #     f.write(response.text)
            db.insert_records(item)
            return item
    except Exception as e:
        return {
            "status_code": 500,
            "content": {"status": "error", "message": str(e)}
        }

@app.get("/crp")
def creq_pdp(url : str):
    """curl-cffi request pdp"""

    from curl_cffi import requests
    from curl_cffi.requests import BrowserType
    impersonate_list = [i.value for i in BrowserType]

    # batter not to use headers beacause curl-cffi provide it with TLS, JA3, fingerprinting, randon sea-ca may trigger blocking
    file_path = os.path.join(db.SAVE_PATH, "crp")
    os.makedirs(file_path,exist_ok=True)
    try:
        response = requests.get(url,impersonate=random.choice(impersonate_list))
        if response.status_code == 200:
            file_hash_key = hashlib.sha256(f"200{url}crp{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
            pagesave_path = os.path.join(file_path,f"{file_hash_key}.html")
            item = {"status":200,
                    "url":url,
                    "req_type":"crp",
                    "pagesave":pagesave_path,
                    "timestamp_time" : datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                    "file_hash_key":file_hash_key
            }

            with open(pagesave_path, "w", encoding="utf-8") as f:
                f.write(response.text)
            db.insert_records(item)
            return item
        else:
            file_hash_key = hashlib.sha256(f"{response.status_code}{url}crp{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
            pagesave_path = os.path.join(file_path,f"{file_hash_key}.html")
            item = {
                    "status": response.status_code,
                    "url": url,
                    "req_type": "crp",
                    "pagesave":pagesave_path,
                    "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                    "file_hash_key": file_hash_key
            }
            # with open(pagesave_path, "w", encoding="utf-8") as f:
            #     f.write(response.text)
            db.insert_records(item)
            return item
    except Exception as e:
        return {
            "status_code":500,
            "content":{"status": "error", "message": str(e)}
        }
@app.get("/crsp")
def creq_session_pdp(url : str):
    """crsp = curl request with session pdp"""
    from curl_cffi import requests
    from curl_cffi.requests import BrowserType
    impersonate_list = [i.value for i in BrowserType]

    # batter not to use headers because curl-cffi provide it with TLS, JA3, fingerprinting, randon sea-ca may trigger blocking
    file_path = os.path.join(db.SAVE_PATH, "crsp")
    os.makedirs(file_path, exist_ok=True)
    try:
        session = requests.Session()
        response = session.get(url, impersonate=random.choice(impersonate_list))
        session.close()
        if response.status_code == 200:
            file_hash_key = hashlib.sha256(
                f"200{url}crsp{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
            pagesave_path = os.path.join(file_path,f"{file_hash_key}.html")
            item = {"status": 200,
                    "url": url,
                    "req_type": "crsp",
                    "pagesave": pagesave_path,
                    "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                    "file_hash_key": file_hash_key
                    }

            with open(pagesave_path, "w", encoding="utf-8") as f:
                f.write(response.text)
            db.insert_records(item)
            return item
        else:
            file_hash_key = hashlib.sha256(
                f"{response.status_code}{url}crsp{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
            pagesave_path = os.path.join(file_path,f"{file_hash_key}.html")
            item = {
                "status": response.status_code,
                "url": url,
                "req_type": "crsp",
                "pagesave": pagesave_path,
                "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                "file_hash_key": file_hash_key
            }
            # with open(pagesave_path, "w", encoding="utf-8") as f:
            #     f.write(response.text)
            db.insert_records(item)
            return item
    except Exception as e:
        return {
            "status_code": 500,
            "content": {"status": "error", "message": str(e)}
        }

@app.get("/crpp")
def creq_proxy_pdp(url : str):
    """crpp = curl request proxy pdp"""
    from curl_cffi import requests
    from curl_cffi.requests import BrowserType
    import urllib.parse
    impersonate_list = [i.value for i in BrowserType]

    # batter not to use headers beacause curl-cffi provide it with TLS, JA3, fingerprinting, randon sea-ca may trigger blocking
    file_path = os.path.join(db.SAVE_PATH, "crpp")
    os.makedirs(file_path, exist_ok=True)
    try:
        token = "876484b6eb084b818e74e53e26d5e519302cbab8e78"
        targetUrl = urllib.parse.quote(url)
        url = "http://api.scrape.do/?token={}&url={}".format(token, targetUrl)
        response = requests.get(url, impersonate=random.choice(impersonate_list))
        if response.status_code == 200:
            file_hash_key = hashlib.sha256(
                f"200{url}crpp{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
            SAVE_PATH = f"{file_path}/{file_hash_key}.html"
            item = {"status": 200,
                    "url": url,
                    "req_type": "crpp",
                    "pagesave": SAVE_PATH,
                    "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                    "file_hash_key": file_hash_key
                    }

            with open(SAVE_PATH, "w", encoding="utf-8") as f:
                f.write(response.text)
            db.insert_records(item)
            return item
        else:
            file_hash_key = hashlib.sha256(
                f"{response.status_code}{url}crpp{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
            SAVE_PATH = f"{file_path}/{file_hash_key}.html"
            item = {
                "status": response.status_code,
                "url": url,
                "req_type": "crpp",
                "pagesave": None,
                "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                "file_hash_key": file_hash_key
            }
            # with open(SAVE_PATH, "w", encoding="utf-8") as f:
            #     f.write(response.text)
            db.insert_records(item)
            return item
    except Exception as e:
        return {
            "status_code": 500,
            "content": {"status": "error", "message": str(e)}
        }
@app.get("/crspp")
def creq_proxy_session_pdp(url : str):
    """crspp = curl request proxy session pdp"""
    from curl_cffi import requests
    from curl_cffi.requests import BrowserType
    import urllib.parse
    impersonate_list = [i.value for i in BrowserType]

    # batter not to use headers because curl-cffi provide it with TLS, JA3, fingerprinting, randon sea-ca may trigger blocking
    file_path = os.path.join(db.SAVE_PATH, "crspp")
    os.makedirs(file_path, exist_ok=True)
    try:
        token = "876484b6eb084b818e74e53e26d5e519302cbab8e78"
        targetUrl = urllib.parse.quote(url)
        url = "http://api.scrape.do/?token={}&url={}".format(token, targetUrl)
        session = requests.Session()
        response = session.get(url, impersonate=random.choice(impersonate_list))
        session.close()
        if response.status_code == 200:
            file_hash_key = hashlib.sha256(
                f"200{url}crspp{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
            SAVE_PATH = f"{file_path}/{file_hash_key}.html"
            item = {"status": 200,
                    "url": url,
                    "req_type": "crspp",
                    "pagesave": SAVE_PATH,
                    "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                    "file_hash_key": file_hash_key
                    }

            with open(SAVE_PATH, "w", encoding="utf-8") as f:
                f.write(response.text)
            db.insert_records(item)
            return item
        else:
            file_hash_key = hashlib.sha256(
                f"{response.status_code}{url}crspp{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
            SAVE_PATH = f"{file_path}/{file_hash_key}.html"
            item = {
                "status": response.status_code,
                "url": url,
                "req_type": "crspp",
                "pagesave": None,
                "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                "file_hash_key": file_hash_key
            }
            # with open(SAVE_PATH, "w", encoding="utf-8") as f:
            #     f.write(response.text)
            db.insert_records(item)
            return item
    except Exception as e:
        return {
            "status_code": 500,
            "content": {"status": "error", "message": str(e)}
        }

@app.get("/srtp")
def req_thread_pdp(url :str):
    '''srtp = simple request thread pdp... '''
    try:
        response_json = request_thread_pdp(url)
        item = {
            "status": json.dumps(response_json.get("response_Status",None)),
            "url": url,
            "req_type": "srtp",
            "pagesave": None,
            "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
            "file_hash_key": None
        }
        db.insert_records(item)
        return item
    except Exception as e:
        return {
            "status_code":500,
            "content":{"status": "error", "message": str(e)}
        }

@app.get("/srstp")
def req_session_thread_pdp(url : str):
    '''srstp = simple request session thread pdp...'''
    try:
        response_json = request_session_thread_pdp(url)
        item = {
            "status": json.dumps(response_json.get("response_Status",None)),
            "url": url,
            "req_type": "srstp",
            "pagesave": None,
            "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
            "file_hash_key": None
        }
        db.insert_records(item)
        return item
    except Exception as e:
        return {
            "status_code":500,
            "content":{"status": "error", "message": str(e)}
        }

@app.get("/crtp")
def curl_request_thread_pdp(url :str):
    """crtp = curl cffi request thread pdp..."""
    try:
        response_json = curl_thread_pdp(url)
        item = {
            "status": json.dumps(response_json.get("response_Status",None)),
            "url": url,
            "req_type": "crtp",
            "pagesave": None,
            "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
            "file_hash_key": None
        }
        db.insert_records(item)
        return item
    except Exception as e:
        return {
            "status_code":500,
            "content":{"status": "error", "message": str(e)}
        }

@app.get("/crstp")
def curl_req_session_thread_pdp(url : str):
    try:
        response_json = curl_session_thread_pdp(url)
        item = {
            "status": json.dumps(response_json.get("response_Status", None)),
            "url": url,
            "req_type": "crstp",
            "pagesave": None,
            "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
            "file_hash_key": None
        }
        db.insert_records(item)
        return item
    except Exception as e:
        return {
            "status_code": 500,
            "content": {"status": "error", "message": str(e)}
        }

@app.get("/crtpp")
def curl_req_proxy_thread_pdp(url : str):
    """crtpp = curl request thread proxy pdp"""
    try:
        response_json = curl_thread_proxy_pdp(url)
        item = {
            "status": json.dumps(response_json.get("response_Status", None)),
            "url": url,
            "req_type": "crtpp",
            "pagesave": None,
            "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
            "file_hash_key": None
        }
        db.insert_records(item)
        return item
    except Exception as e:
        return {
            "status_code": 500,
            "content": {"status": "error", "message": str(e)}
        }

@app.get("/crtspp")
def curl_req_thread_session_proxy_pdp(url : str):
    """crtspp = curl request thread session proxy pdp"""
    try:
        response_json = curl_thread_proxy_session_pdp(url)
        item = {
            "status": json.dumps(response_json.get("response_Status", None)),
            "url": url,
            "req_type": "crtspp",
            "pagesave": None,
            "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
            "file_hash_key": None
        }
        db.insert_records(item)
        return item
    except Exception as e:
        return {
            "status_code": 500,
            "content": {"status": "error", "message": str(e)}
        }
@app.get("/seleniumPDP")
def selenium_req(url :str):
    from selenium import webdriver
    from selenium.webdriver.chrome.service import Service
    from selenium.webdriver.chrome.options import Options
    from webdriver_manager.chrome import ChromeDriverManager

    def is_blocked(driver):
        html = driver.page_source.lower()
        title = driver.title.lower()
        url = driver.current_url.lower()

        block_signs = [
            "cf-challenge",
            "captcha",
            "access denied",
            "verify you are human",
            "attention required",
            "just a moment","forbidden","Press & Hold"
        ]

        if any(sign in html for sign in block_signs):
            return True

        if any(sign in title for sign in block_signs):
            return True

        if "/cdn-cgi/" in url:
            return True

        return False
    file_path = os.path.join(db.SAVE_PATH, "srp")
    os.makedirs(file_path, exist_ok=True)
    options = Options()
    options.add_argument("--start-maximized")
    options.add_argument("--headless=False")
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service,options = options)
    driver.get(url)
    content = driver.page_source
    if is_blocked(driver):
        print("Blocked detected!")
        file_hash_key = hashlib.sha256(
            f"201{url}selenium{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
        SAVE_PATH = f"{file_path}/{file_hash_key}.html"
        with open(SAVE_PATH, "w", encoding="utf-8") as f:
            f.write(content)
        #201 indicate some issue check pagesave for this...
        item = {
            "status": 201,
            "url": url,
            "req_type": "selenium",
            "pagesave": SAVE_PATH,
            "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
            "file_hash_key": file_hash_key
        }
        db.insert_records(item)
        return item
    else:
        print("Page loaded normally")
        file_hash_key = hashlib.sha256(
            f"200{url}selenium{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
        SAVE_PATH = f"{file_path}/{file_hash_key}.html"
        with open(SAVE_PATH, "w", encoding="utf-8") as f:
            f.write(content)
        item = {
            "status": 200,
            "url": url,
            "req_type": "selenium",
            "pagesave": SAVE_PATH,
            "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
            "file_hash_key": file_hash_key
        }
        db.insert_records(item)
        return item
    driver.quit()

@app.get("/playwrightTest")
def playwright_req(url : str):
    from playwright.sync_api import sync_playwright
    file_path = os.path.join(db.SAVE_PATH, "srp")
    os.makedirs(file_path, exist_ok=True)
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        page = browser.new_context().new_page()
        page.goto("https://www.zillow.com/")
        page.wait_for_load_state("networkidle")
        content = page.content()
        try:
            if "captcha" in page.content() or "Press & Hold":
                print("Blocked!")
                file_hash_key = hashlib.sha256(
                    f"201{url}playwright{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
                SAVE_PATH = f"{file_path}/{file_hash_key}.html"
                with open(SAVE_PATH, "w", encoding="utf-8") as f:
                    f.write(content)
                # 201 indicate some issue check pagesave for this...
                item = {
                    "status": 201,
                    "url": url,
                    "req_type": "playwright",
                    "pagesave": SAVE_PATH,
                    "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                    "file_hash_key": file_hash_key
                }
                db.insert_records(item)
                return item
            else:
                file_hash_key = hashlib.sha256(
                    f"200{url}playwright{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
                SAVE_PATH = f"{file_path}/{file_hash_key}.html"
                with open(SAVE_PATH, "w", encoding="utf-8") as f:
                    f.write(content)
                # 201 indicate some issue check pagesave for this...
                item = {
                    "status": 200,
                    "url": url,
                    "req_type": "playwright",
                    "pagesave": SAVE_PATH,
                    "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                    "file_hash_key": file_hash_key
                }
                db.insert_records(item)
                return item
            browser.close()
        except Exception as e:
            item = {
                "status": 500,
                "url": url,
                "req_type": "playwright",
                "pagesave": None,
                "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                "file_hash_key": "Blocking"
            }
            db.insert_records(item)
            return item

@app.get("/drissionpagePDP")
def drission_page_req(url : str):
    from DrissionPage import ChromiumPage
    file_path = os.path.join(db.SAVE_PATH, "srp")
    os.makedirs(file_path, exist_ok=True)
    timestamp = datetime.now().strftime('%d-%m-%Y-%H-%M-%S-%f')[:-3]
    page = ChromiumPage()
    sucess = page.get(url)
    content = page.html
    block_keywords = [
        "captcha",
        "verify you are human",
        "access denied",
        "cloudflare",
    ]
    is_blocked = any(word in content.lower() for word in block_keywords)
    status_code = 200 if sucess else 201
    if status_code != 200 or is_blocked:
        file_hash_key = hashlib.sha256(
            f"201{url}drissionpage{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
        SAVE_PATH = f"{file_path}/{file_hash_key}.html"
        with open(SAVE_PATH, "w", encoding="utf-8") as f:
            f.write(content)
        # 201 indicate some issue check pagesave for this...
        item = {
            "status": 201,
            "url": url,
            "req_type": "drissionpage",
            "pagesave": SAVE_PATH,
            "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
            "file_hash_key": file_hash_key
        }
        db.insert_records(item)
        return item
    else:
        file_hash_key = hashlib.sha256(
            f"200{url}drission_page{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
        SAVE_PATH = f"{file_path}/{file_hash_key}.html"
        with open(SAVE_PATH, "w", encoding="utf-8") as f:
            f.write(content)
        # 201 indicate some issue check pagesave for this...
        item = {
            "status": 200,
            "url": url,
            "req_type": "drissionpage",
            "pagesave": SAVE_PATH,
            "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
            "file_hash_key": file_hash_key
        }
        db.insert_records(item)
        return item


if __name__ == "__main__":
    # create_table()
    # session_id = str(uuid.uuid4())
    # cookies = {
    #     "session_id": session_id
    # }
    # url = 'https://books.toscrape.com/'
    # result = selenium_req(url)
    # result = req_pdp(url)

    # print(json.dumps(req_pdp(url)))
    uvicorn.run(
        "main:app",
        host="0.0.0.0",  # allow network
        port=8000,  # your port
        reload=True
    )
    # uvicorn.run("main:app",host="0.0.0.0",port=8000,reload=True)