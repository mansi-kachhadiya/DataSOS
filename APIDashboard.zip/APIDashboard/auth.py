import bcrypt
import jwt
from datetime import datetime, timedelta
from fastapi import HTTPException
from models import User
from database import SessionLocal
from fastapi import Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
import jwt
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")


SECRET = "secret"

def create_token(user: User):
    payload = {
        "sub": user.username,
        "role": user.role,
        "exp": datetime.utcnow() + timedelta(minutes=60)
    }
    return jwt.encode(payload, SECRET, algorithm="HS256")

def role_required(allowed_roles: list[str]):
    def checker(token: str = Depends(oauth2_scheme)):
        payload = jwt.decode(token, SECRET, algorithms=["HS256"])
        user_role = payload.get("role")

        if user_role not in allowed_roles:
            raise HTTPException(status_code=403, detail="Not allowed")

        return payload
    return checker