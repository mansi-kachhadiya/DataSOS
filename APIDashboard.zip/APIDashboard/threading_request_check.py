from concurrent.futures import ThreadPoolExecutor ,as_completed
from collections import Counter

def request_thread_pdp(url):
    #srtp = simple request thread pdp
    import requests
    results = []
    total_Request = 2000
    def worker():
        response = requests.get(url)
        return response
    with ThreadPoolExecutor(max_workers=50) as executor:
        futures = [executor.submit(worker) for _ in range(total_Request)]

        for future in as_completed(futures):
            response = future.result()
            if response is not None and response.status_code == 200:
                content = response.text.lower()
                if "<html" in content and "<script" in content:
                    results.append(response.status_code)
                else:
                    # responses.append(response)
                    #201 indication for empty response is 200 but empty
                    results.append(201)
            else:
                results.append(response.status_code)
    status_count = dict(Counter(results))

    return {"total_sent": total_Request,
            "response_Status": status_count}

def request_session_thread_pdp(url):
    #srstp = simple request session thread pdp
    import requests
    results = []
    total_Request = 2000

    def worker():
        session = requests.Session()
        response = session.get(url)
        session.close()
        return response

    with ThreadPoolExecutor(max_workers=50) as executor:
        futures = [executor.submit(worker) for _ in range(total_Request)]

        for future in as_completed(futures):
            response = future.result()
            if response is not None and response.status_code == 200:
                content = response.text.lower()
                if "<html" in content and "<script" in content:
                    results.append(response.status_code)
                else:
                    # responses.append(response)
                    # 201 indication for empty response is 200 but empty
                    results.append(201)
            else:
                results.append(response.status_code)
    status_count = dict(Counter(results))

    return {"total_sent": total_Request,
            "response_Status": status_count}

def curl_thread_pdp(url, curl_cffi=None):
    #srtp = simple request thread pdp
    from curl_cffi import requests
    from curl_cffi.requests import BrowserType
    import random
    impersonte_list = [p.value for p in BrowserType]
    results = []
    total_Request = 2000
    def worker():
        response = requests.get(url,impersonate=random.choice(impersonte_list))
        return response
    with ThreadPoolExecutor(max_workers=50) as executor:
        futures = [executor.submit(worker) for _ in range(total_Request)]

        for future in as_completed(futures):
            response = future.result()
            if response is not None and response.status_code == 200:
                content = response.text.lower()
                if "<html" in content and "<script" in content:
                    results.append(response.status_code)
                else:
                    # responses.append(response)
                    #201 indication for empty response is 200 but empty
                    results.append(201)
            else:
                results.append(response.status_code)
    status_count = dict(Counter(results))

    return {"total_sent": total_Request,
            "response_Status": status_count}

def curl_session_thread_pdp(url):
    # crstp = curl request session thread pdp
    from curl_cffi import requests
    from curl_cffi.requests import BrowserType
    import random
    impersonte_list = [p.value for p in BrowserType]
    results = []
    total_Request = 2000

    def worker():
        session = requests.Session()
        response = session.get(url, impersonate=random.choice(impersonte_list))
        session.close()
        return response

    with ThreadPoolExecutor(max_workers=50) as executor:
        futures = [executor.submit(worker) for _ in range(total_Request)]

        for future in as_completed(futures):
            response = future.result()
            if response is not None and response.status_code == 200:
                content = response.text.lower()
                if "<html" in content and "<script" in content:
                    results.append(response.status_code)
                else:
                    # responses.append(response)
                    # 201 indication for empty response is 200 but empty
                    results.append(201)
            else:
                results.append(response.status_code)
    status_count = dict(Counter(results))

    return {"total_sent": total_Request,
            "response_Status": status_count}

def curl_thread_proxy_pdp(url):
    #crtpp = curl request thread proxy pdp
    from curl_cffi import requests
    from curl_cffi.requests import BrowserType
    import random
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    impersonte_list = [p.value for p in BrowserType]
    results = []
    total_Request = 100
    token = "876484b6eb084b818e74e53e26d5e519302cbab8e78"
    proxyModeUrl = "http://{}:@proxy.scrape.do:8080".format(token)
    proxies = {
        "http": proxyModeUrl,
        "https": proxyModeUrl,
    }
    def worker():
        response = requests.get(url, proxies=proxies, impersonate=random.choice(impersonte_list),verify=False)
        return response

    with ThreadPoolExecutor(max_workers=50) as executor:
        futures = [executor.submit(worker) for _ in range(total_Request)]

        for future in as_completed(futures):
            response = future.result()
            if response is not None and response.status_code == 200:
                content = response.text.lower()
                if "<html" in content and "<script" in content:
                    results.append(response.status_code)
                else:
                    # responses.append(response)
                    # 201 indication for empty response is 200 but empty
                    results.append(201)
            else:
                results.append(response.status_code)
    status_count = dict(Counter(results))

    return {"total_sent": total_Request,
            "response_Status": status_count}

def curl_thread_proxy_session_pdp(url):
    #crtspp = curl request thread session proxy pdp
    from curl_cffi import requests
    from curl_cffi.requests import BrowserType
    import random
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    impersonte_list = [p.value for p in BrowserType]
    results = []
    total_Request = 100
    token = "876484b6eb084b818e74e53e26d5e519302cbab8e78"
    proxyModeUrl = "http://{}:@proxy.scrape.do:8080".format(token)
    proxies = {
        "http": proxyModeUrl,
        "https": proxyModeUrl,
    }

    def worker():
        session = requests.Session()
        response = session.get(url, proxies=proxies, impersonate=random.choice(impersonte_list), verify=False)
        session.close()
        return response

    with ThreadPoolExecutor(max_workers=50) as executor:
        futures = [executor.submit(worker) for _ in range(total_Request)]

        for future in as_completed(futures):
            response = future.result()
            if response is not None and response.status_code == 200:
                content = response.text.lower()
                if "<html" in content and "<script" in content:
                    results.append(response.status_code)
                else:
                    # responses.append(response)
                    # 201 indication for empty response is 200 but empty
                    results.append(201)
            else:
                results.append(response.status_code)
    status_count = dict(Counter(results))

    return {"total_sent": total_Request,
            "response_Status": status_count}



